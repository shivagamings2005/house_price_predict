from flask import Flask,request,jsonify
from util import get_location,estimate_price,load_detatils
app=Flask(__name__)
@app.route("/get_location")
def getloc():
    response=jsonify({'locations':get_location()})
    response.headers.add("Access-Control-Allow-Origin","*")
    return response
@app.route("/predict",methods=['GET', 'POST'])
def predict_price():
    total_sqft=float(request.form['total_sqft'])
    locations=request.form['locations']
    bhk=int(request.form['bhk'])
    bath=int(request.form['bath'])
    #print(locations,total_sqft,bhk,bath)
    response=jsonify({'estimated_price':estimate_price(locations,total_sqft,bhk,bath)})
    response.headers.add("Access-Control-Allow-Origin","*")
    return response
if __name__=="__main__":
    print("flask started")
    load_detatils()
    app.run()