import json
import pickle
import numpy as np
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn")
def estimate_price(loc,sqft,bhk,bath):
    try:
        loc_index = data_columns.index(loc.lower())
    except:
        loc_index=-1
    x1 = np.zeros(len(data_columns))
    x1[0] = sqft
    x1[1] = bath
    x1[2] = bhk
    if loc_index >= 0:
        x1[loc_index] = 1
    return round(model.predict([x1])[0],2)
def get_location():
    return locations
def load_detatils():
    print("loaded started")
    global locations,data_columns,model
    with open('D:\\house\\server\\artifacts\\columns.json','r') as f:
        data_columns=json.load(f)['data_columns']
        locations=data_columns[3:]
    with open('D:\\house\\server\\artifacts\\home_prices_model.pickle','rb') as f:
        model=pickle.load(f)
    print("loaded successfully!")
locations=None
data_columns=None
model=None